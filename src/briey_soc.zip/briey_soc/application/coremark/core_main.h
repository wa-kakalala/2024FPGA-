#ifndef _CORE_MAIN_H
#define _CORE_MAIN_H




void core_main(void);

#endif